﻿using System;
using System.Collections.Generic;
using System.Text;

namespace InternalsViewer.Internals.BlobPointers
{
    public class Field: Markable
    {

    }
}
