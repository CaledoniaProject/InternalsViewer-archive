## User Guide
**Contents**

[Toolbar and menu bar](Toolbar-and-menu-bar)

[Allocation Map](Allocation-Map)

[Page Viewer](Page-Viewer)

[Transaction Log Viewer](Transaction-Log-Viewer)

[Object Explorer Integration](Object-Explorer-Integration)