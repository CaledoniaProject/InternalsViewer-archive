## Page Viewer
**Opening the Page Viewer**

The Page Viewer can be opened in several ways:
	* Clicking on a page in the Allocation Map.
	* Typing a page address in the Page Address text box on the Allocation Map toolbar and pressing Enter.
	* Clicking on a page address link in the Transaction Log Viewer.
**Page Viewer**

The Page Viewer consists of four parts; the header, hex viewer, the offset table, and the record interpretation/allocation map.

![](Page Viewer_page_viewer.png)

**_Header_**

The header panel on the left hand side displays information from the page header (highlighted in blue at the top of the Hex Viewer). 

All entries on the header can be selected and copied to the clipboard as text.

Page Address links in blue can be clicked on to open the page at that address in a new window.

![](Page Viewer_page_address.png)

The header panel also includes the allocation status for the page, including the GAM, SGAM, DCM, and BCM pages as well as the PFS status. The page addresses for the relevant allocation page are displayed next to the allocation status.

![](Page Viewer_allocation_status.png)

**_Hex Viewer_**

The Hex Viewer displays the raw bytes of the page. 

If a record is selected, the Hex Viewer will be colourised to show the different elements in the record. 

![](Page Viewer_colourised_record.png)

Hovering over a colourised element will display information about it in the bottom right hand corner on the Page Viewer status bar. The offset at the location of the mouse pointer is also displayed on the status bar.

![](Page Viewer_status_bar.png)

Selecting data on the Hex Viewer will display a decoded interpretation of the data for applicable data-types. For example, if the selection is 4 bytes long the selection will be decoded as an INT, as well as a VARCHAR as both of these are possible types.

![](Page Viewer_decode.png)

Right clicking on the Hex Viewer gives two options:

![](Page Viewer_hex_viewer_menu.png)

* Set Offset to: (offset)
	* This will set the row decoding to the specified offset.
* Select Record
	* This will select the record that the byte selected is part of

If the page is an allocation page hovering over a byte will show which extents the byte represents if the byte is part of the allocation information.

![](Page Viewer_extents_status_bar.png)

**_Offset Table_**

The offset table allows records in the page to be selected by clicking on the different offsets.

![](Page Viewer_offset_table.png)

An offset can also be set by typing the offset in the Offset text box on the Page Viewer toolbar.

**_Record Interpretation/Allocation Map_**

If a page is an index or data page the bottom half of the Page Viewer will show the Record Interpretation.

The record interpretation shows the different elements that make up a record. The elements are colour coded and displayed on the hex viewer.

![](Page Viewer_record_interpretation.png)

The record interpretation shows the key colour, the description of the element, its value, and start and end offset on the page.

Clicking on an element in the record interpretation table will select it on the hex viewer.

If a page is an allocation (IAM, GAM etc.) page the lower half of the Page Viewer will show the allocation information the page contains.

![](Page Viewer_allocation_map.png)

Hovering over a page will display its address on the status bar and clicking on a page will open it in the Page Viewer.

**Back and Forwards buttons**

![](Page Viewer_back_forwards_buttons.png)

The Back and Forwards buttons move the page viewer to the previous or next page in the file.