# Resources

## Internals Viewer

[SQL Internals Viewer feature on LearnSQLServer.com (Requires subscription)](http://www.learnsqlserver.com/VideoTutorials/Sql-Server-Tutorials/285/Series-3-videos-A-Deeper-Look-at-Pages-and-Extents.aspx)

[SQL Server Central Article](http://www.sqlservercentral.com/articles/Product+Reviews/3200/)

## Pages

[Books Online - Pages and Extents](http://msdn2.microsoft.com/en-us/library/ms190969.aspx)

[SQL Server Storage Engine (Paul Randal) - What are pages?](https://blogs.msdn.com/sqlserverstorageengine/archive/2006/06/26/647005.aspx)

[SQL Server Storage Engine (Paul Randal) - What are extents?](http://blogs.msdn.com/sqlserverstorageengine/archive/2006/06/28/649884.aspx)

[SQL Server Magazine (Kalen Delaney) - Using DBCC PAGE (Requires subscription)](http://www.sqlmag.com/Article/ArticleID/8097/sql_server_8097.html)

GAM, SGAM, and PFS Pages

[Books Online - Managing Extent Allocations and Free Space](http://msdn2.microsoft.com/en-us/library/ms175195.aspx)

[SQL Server Storage Engine (Paul Randal) - Under the covers - GAM, SGAM, and PFS pages](http://msdn2.microsoft.com/en-us/library/ms175195.aspx)

[SQL Server Magazine (Kalen Delaney) - The New Space Management (Requires subscription)](http://www.sqlmag.com/Articles/ArticleID/5110/pg/1/1.html)

[SQL Server Magazine (Kalen Delaney) - Mixed Extent Usage (Requires subscription)](http://www.sqlmag.com/Articles/ArticleID/43418/43418.html)

IAM Pages

[Books Online - Managing Space Used by Objects](http://msdn2.microsoft.com/en-us/library/ms187501.aspx)

[SQL Server Storage Engine (Paul Randal) - Under the covers - IAM chains in SQL Server 2000](http://blogs.msdn.com/sqlserverstorageengine/archive/2006/06/24/645803.aspx)

[SQL Server Storage Engine (Paul Randal) - Under the covers - IAM chains and allocation units in SQL Server 2005](http://blogs.msdn.com/sqlserverstorageengine/archive/2006/06/25/under-the-covers-iam-chains-and-allocation-units-in-sql-server-2005.aspx)

DCM and BCM Pages

[Books Online - Tracking Modified Extents](http://msdn2.microsoft.com/en-us/library/ms190950.aspx)

Table and Index Structure

[Books Online - Heap Structures](http://msdn2.microsoft.com/en-us/library/ms188270.aspx)

[Books Online - Clustered Index Structures](http://msdn2.microsoft.com/en-us/library/ms177443.aspx)

[Books Online - Nonclustered Index Structures](http://msdn2.microsoft.com/en-us/library/ms177484.aspx)

[SQL Server Storage Engine (Paul Randal) - Poking about with DBCC PAGE (Part 1 of -)](http://blogs.msdn.com/sqlserverstorageengine/archive/2006/08/09/692806.aspx)

[SQL Server Magazine (Kalen Delaney) - Get Into Index Structures (Requires subscription)](http://www.sqlmag.com/Article/ArticleID/43939/sql_server_43939.html) 
