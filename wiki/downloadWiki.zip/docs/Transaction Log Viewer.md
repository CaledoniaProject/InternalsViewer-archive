## Transaction Log Viewer
The Transaction Log Viewer integrates with the SQL Server Management Studio query window.

To enable the viewer check the menu option _**Internals Viewer – Display Transaction Log**_.

![](Transaction Log Viewer_display_transaction_log.png)

**Note** The Transaction Log Viewer uses checkpoints to monitor the transaction log. It should only be used on non-production SQL Servers as the checkpoints may cause performance issues.

When the Transaction Log Viewer is enabled an extra Transaction Log tab will be displayed in the Query Results pane.

![](Transaction Log Viewer_transaction_log_viewer.png)

The Transaction Log tab shows the following information:

* LSN – Log Sequence Number
* Operation – The transaction log operation
* Context – The context of the operation
* Page – The page the operation applied to. This can be clicked on the open the page in the Page Viewer.
* Slot – The slot the operation applied to. This can be clicked on to open the page/slot in the Page Viewer
* Allocation Unit
* Description – Additional information

Green text on the Transaction Log Viewer indicates the operation is related to allocation

Gray text indicates the operation is related to a system object