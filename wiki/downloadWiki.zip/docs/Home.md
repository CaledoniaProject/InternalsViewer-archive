**Project Description**

Internals Viewer is a tool for looking into the SQL Server storage engine and seeing how data is physically allocated, organised and stored.

All sorts of tasks performed by a DBA or developer can benefit greatly from knowledge of what the storage engine is doing and how it works

[User Guide](User-Guide)

[Troubleshooting](Troubleshooting)

[Previous Versions (Including standalone version)](Previous-Versions-(Including-standalone-version))

**Features**

* Integration with SSMS (SQL Server Management Studio) 2005 and 2008
	* The application is installed as a SSMS add-in
	* Internals information integrated into the Object Explorer
	* Transaction Log viewer integrated into the Query Results

* Allocation Map
	* Displays the physical layout of tables and indexes
	* Displays PFS status
	* Overlay pages in the Buffer Pool

* Page Viewer
	* Displays Data pages including forwarding records and sparse columns
	* Displays Index pages
	* Displays allocation pages (IAM, GAM, SGAM, DCM, and BCM pages)
	* Displays pages with SQL Server 2008 row and page compression

[Resources](Resources)