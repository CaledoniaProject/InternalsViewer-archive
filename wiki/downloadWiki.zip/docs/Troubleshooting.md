## Troubleshooting
**No add-in**

If you have installed Internals Viewer but there is no add-in check the following registry settings and ensure _LoadBehavior_ is set to 1

_SQL Server 2005_

{"HKEY_CURRENT_USER\Software\Microsoft\Microsoft SQL Server\90\Tools\Shell\Addins\InternalsViewer.SSMSAddIn.Connect"}

_SQL Server 2008_

{"HKEY_CURRENT_USER\Software\Microsoft\Microsoft SQL Server\100\Tools\Shell\Addins\InternalsViewer.SSMSAddIn.Connect"}

If the LoadBehavior registry entry is missing the following files should be imported:

* SQL Server 2005 - [InternalsViewer20081228-90.reg](Troubleshooting_InternalsViewer20081228-90.reg)
* SQL Server 2008 - [InternalsViewer20081228-100.reg](Troubleshooting_InternalsViewer20081228-100.reg)

**Other Issues**

If you are having other issues with the application please log them in the Issue Tracker.