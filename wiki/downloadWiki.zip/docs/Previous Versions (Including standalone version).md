# Previous Versions

**[SqlInternalsViewer_1_0_2.zip](Previous Versions (Including standalone version)_SqlInternalsViewer_1_0_2.zip) (Current standalone version)**

[SqlInternalsViewer_1_0_1.zip](Previous Versions (Including standalone version)_SqlInternalsViewer_1_0_1.zip)

[SqlInternalsViewer_1_0.zip](Previous Versions (Including standalone version)_SqlInternalsViewer_1_0.zip)

[SqlInternalsViewer_0_12.zip](Previous Versions (Including standalone version)_SqlInternalsViewer_0_12.zip)

[SqlInternalsViewer_0_11_1.zip](Previous Versions (Including standalone version)_SqlInternalsViewer_0_11_1.zip)

[SqlInternalsViewer_0_10.zip](Previous Versions (Including standalone version)_SqlInternalsViewer_0_10.zip)

[SqlInternalsViewer_0_9_1.zip](Previous Versions (Including standalone version)_SqlInternalsViewer_0_9_1.zip)

[SqlInternalsViewer_0_8.zip](Previous Versions (Including standalone version)_SqlInternalsViewer_0_8.zip)

[SqlInternalsViewer_0_7.zip](Previous Versions (Including standalone version)_SqlInternalsViewer_0_7.zip)

[SqlInternalsViewer_0_6.zip](Previous Versions (Including standalone version)_SqlInternalsViewer_0_6.zip)







