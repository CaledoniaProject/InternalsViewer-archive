## Allocation Map
The Allocation Map shows a graphical representation of the layout of pages and extents in a database file or files.

**Connecting to a server**

When the Allocation Map is opened the Connect to SQL Server dialog box is show.

To connect the Allocation Map to a different SQL Server instance click the Connect to Server button:

![](Allocation Map_connect_to_server.png)

**Databases**

The database displayed in the allocation map can be changed using the Database drop down list.

![](Allocation Map_databases_dropdown.png)
 
When a database is first loaded Internals Viewer will scan through the object IAMs to build the allocation map. Progress can be seen on status bar in the bottom left.
 
Different objects are given different colours. 

![](Allocation Map_allocation_map.png)

**Pages**

When the mouse is hovered over a page the status bar will display the page address and object that the page is allocated to in the bottom right hand corner.

![](Allocation Map_page_info.png)
 
Clicking on a page in the Allocation Map will open it in the Page Viewer.

**Page Address text box**

The page text box is in the top right hand corner of the Allocation Map window. Typing a page address in the format file id: page id and then pressing Enter will open the page in the Page Viewer.

![](Allocation Map_go_to_page.png)

Right clicking on a page address in the page text box will give several options:

![](Allocation Map_page_copy_options.png)

* Copy – this will copy the page address to the clipboard
* Copy DDBC command to Clipboard – these options will script the necessary commands to view the page from a query window with DBCC PAGE

![](Allocation Map_dbcc_page.png)

**Key**

A key is displayed at the bottom of the window including the index type, total pages used, and total pages allocated. It can be toggled on and off using the Key toolbar button:
 
![](Allocation Map_key_button.png)

Clicking on an item in the key will highlight the object on the map and dim other objects. Clicking on the same object again will deselect it and show all object on the map.

**File Details**

Toggling the File Details toolbar button will display the file details information at the bottom of the Allocation Map.
 
![](Allocation Map_file_details.png)

File details are sourced from sys.database_files, sys.filegroups, and DBCC showfilestats.  Each file displayed in the Allocation Map will have its own File Details information bar.

**Buffer Pool**

The buffer pool is SQL Server’s page memory cache. Pages can be dirty, which means they have been changed and not yet been written to disk.

A graphical representation of the pages in the buffer pool can be displayed by toggling the Buffer Pool toolbar button.

If a page is in the buffer pool it is darkened. If the page is dirty is has a red mark in the top left hand corner. 

![](Allocation Map_buffer_pool.png)

Not in buffer pool/in buffer pool/in buffer pool + dirty 

Buffer pool information is sourced from sys.dm_os_buffer_descriptors.

_Note_ The buffer pool is read from sys.dm_os_buffer_descriptors and mapped to the allocation map on an individual page basis. If a large number of pages are in the buffer pool Internals Viewer may become slow. 

**PFS**

The PFS (Page Free Space) is another allocation structure that stores the status of individual pages.

![](Allocation Map_pfs_key.png)

The PFS stores several pieces of information including how much space is free on the page, the allocation status (allocated/unallocated), if the page is an IAM, if the page is part of a mixed extent, and if the page contains Ghost Records.

Clicking PFS on the toolbar will put the Allocation Map into PFS mode. 
 
Hovering over a page will display a description of the PFS value for the page in the status bar in the bottom right hand corner of the application.

![](Allocation Map_pfs_info.png)

**Page Size**

The sizes of pages on the Allocation Map are determined by the Page Size drop down. 

![](Allocation Map_page_size.png)

The dropdown has three options; Small, Medium, and Large. By default when the Allocation Map is in PFS mode the page size is set to Large.