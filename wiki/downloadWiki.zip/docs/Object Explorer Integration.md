# Object Explorer Integration
Internals Viewer adds extra nodes to the Object Explorer at the Indexes level.

![](Object Explorer Integration_object_explorer.png)

If an object has no indexes or is a heap (it has no clustered index) a (Heap) node is added to the list of indexes.

![](Object Explorer Integration_heap.png)

Indexes can be expanded to show the three entry points to the table or index.

* First IAM
* Root Page
* First Page

These pages can be double clicked on to open them in the [Page Viewer](Page-Viewer).
