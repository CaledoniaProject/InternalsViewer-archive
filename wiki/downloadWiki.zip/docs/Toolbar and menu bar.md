**Toolbar**

Internals Viewer adds an extra toolbar button to the standard menu in SSMS.

![](Toolbar and menu bar_allocation_map_button.png)

Clicking on it will open the [Allocation Map](Allocation-Map).

**Menu**

An Internals Viewer menu is added to SSMS giving two options. 

![](Toolbar and menu bar_menu.png)

The _Display Transaction Log_ option toggles on and off the [Transaction Log Viewer](Transaction-Log-Viewer).
 
The _Internals Viewer – Allocation Map_ menu option opens the [Allocation Map](Allocation-Map).
